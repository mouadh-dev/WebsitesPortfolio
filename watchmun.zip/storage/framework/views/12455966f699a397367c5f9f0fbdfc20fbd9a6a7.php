<?php $__env->startSection('content'); ?>
    
    
    
    
    
    

    <!-- Corner Borders -->
    

    <section class="gallery">
        <div class="container-fluid">

            <div class="container cont-img ">
                <a href="https://ma3louma.tn" class="thumb-a" target="\_blank">
                    <div class="item-hover">
                        <div class="hover-text">
                            <h3>
                                MA3LOUMA
                            </h3>
                        </div>
                    </div>
                    <div class="item-img">
                        <img class="img-fluid rounded mx-auto d-block" src="<?php echo e(asset('ma3louma.png')); ?>" />
                    </div>
                </a>
            </div>
        </div>

        

        <div class="container height d-flex justify-content-center ">

            <div class="col-md-6">

                <form class="form row align-items-center" action="<?php echo e(route('home.index')); ?>" method="get">
                    <i class="fa fa-search"></i>
                    <input type="text" class="input-search form-control form-input form-group col" placeholder="Search anything..."
                        value="<?php echo e(request('search_query')); ?>" name='search_query' id='search'>
                    <div class=" col align-self-end ">

                        <input type="submit" value="search" class="btn  form-group col align-self-end ">
                    </div>
                    
                </form>

            </div>

        </div>

        

        <div class="row">

            <div class="fw mix-container home-gallery">
                <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mix portrait">
                        <a href="<?php echo e($website->link); ?>" class="thumb-a" target="\_blank">
                            <div class="item-hover">
                                <div class="hover-text">
                                    <h3>
                                        <?php echo e($website->title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="item-img">
                                <img src="<?php echo e(asset($website->images)); ?>" />
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>



    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vitrinemunicipality\resources\views/home/index.blade.php ENDPATH**/ ?>
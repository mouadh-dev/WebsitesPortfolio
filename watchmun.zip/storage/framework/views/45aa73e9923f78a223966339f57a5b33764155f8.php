    <!-- Footer Section -->
    <footer>
        <div class="container-fluid">
              <div class="footer-info">
                <div class="footer-title">
                  <h2>WatchMun</h2>
                  <p>&copy; Copyrights 2022. All Rights Reserved. By <a href="https://www.i-techrity.tn">I-techrity</a></p>
                </div>
                <div class="footer-social">
                  
                  
                  <a href="https://www.instagram.com/i_techrity/"><i class="fab fa-instagram"></i></a>
                  <a href="https://www.linkedin.com/in/i-techrity-i-techrity-358293227"><i class="fab fa-linkedin"></i></a>
                  
                  
                  <a href="https://www.facebook.com/ITechrity"><i class="fab fa-facebook"></i></a>
                  
                </div>
              </div>
        </div>
      </footer>
<?php /**PATH C:\laragon\www\vitrinemunicipality\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>
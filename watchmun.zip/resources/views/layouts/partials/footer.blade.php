    <!-- Footer Section -->
    <footer>
        <div class="container-fluid">
              <div class="footer-info">
                <div class="footer-title">
                  <h2>WatchMun</h2>
                  <p>&copy; Copyrights 2022. All Rights Reserved. By <a href="https://www.i-techrity.tn">I-techrity</a></p>
                </div>
                <div class="footer-social">
                  {{-- <a href=""><i class="fab fa-dribbble"></i></a> --}}
                  {{-- <a href=""><i class="fab fa-behance"></i></a> --}}
                  <a href="https://www.instagram.com/i_techrity/"><i class="fab fa-instagram"></i></a>
                  <a href="https://www.linkedin.com/in/i-techrity-i-techrity-358293227"><i class="fab fa-linkedin"></i></a>
                  {{-- <a href=""><i class="fab fa-500px"></i></a> --}}
                  {{-- <a href=""><i class="fab fa-flickr"></i></a> --}}
                  <a href="https://www.facebook.com/ITechrity"><i class="fab fa-facebook"></i></a>
                  {{-- <a href=""><i class="fab fa-twitter"></i></a> --}}
                </div>
              </div>
        </div>
      </footer>

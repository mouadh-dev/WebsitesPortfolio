<header class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="/">WatchMun</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="icon-bar i1"></span>
        <span class="icon-bar i2"></span>
        <span class="icon-bar i3"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarDefault">
        <ul class="navbar-nav ml-auto" id="navbar">
          <li class="nav-item">
            <a class="nav-link" href="/">HOME <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/about">ABOUT ME</a>
          </li>
          {{-- <li class="nav-item">
            <a class="nav-link" href="portfolio.html">PORTFOLIO</a>
          </li> --}}
          {{-- <li class="nav-item">
            <a class="nav-link" href="contact.html">CONTACT</a>
          </li> --}}
        </ul>

      </div>
    </nav>

</header>
